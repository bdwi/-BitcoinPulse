import SwiftUI
import Charts

@main
struct BitcoinPulseApp: App {
    var body: some Scene {
        WindowGroup {
            Dashboard().preferredColorScheme(.dark)
                .environment(\.layoutDirection, .rightToLeft)
        }
    }
}

struct Candle: Identifiable {
    var id: Double { date.timeIntervalSince1970 }
    let date: Date
    let low: Double
    let high: Double
    let close: Double
}
struct Tick: Decodable { let price: String; let time: String }
struct Stats: Decodable { let open: String; let high: String; let low: String }
struct Snapshot {
    let price: Double
    let change: Double
    let candles: [Candle]
    let tradeTime: Date
}
enum DataError: LocalizedError {
    case invalid, http(Int)
    var errorDescription: String? {
        switch self {
        case .invalid: return "بيانات غير مكتملة من المصدر. حاول مجدداً."
        case .http(let status): return "المصدر غير متاح حالياً (\(status)). حاول لاحقاً."
        }
    }
}
enum MarketAPI {
    static func request<T: Decodable>(_ path: String, as type: T.Type) async throws -> T {
        guard let url = URL(string: "https://api.exchange.coinbase.com/products/BTC-USD/" + path) else { throw DataError.invalid }
        var request = URLRequest(url: url)
        request.timeoutInterval = 20
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        let (data, response) = try await URLSession.shared.data(for: request)
        guard let response = response as? HTTPURLResponse else { throw DataError.invalid }
        guard response.statusCode == 200 else { throw DataError.http(response.statusCode) }
        return try JSONDecoder().decode(type, from: data)
    }
    static func load() async throws -> Snapshot {
        async let ticker = request("ticker", as: Tick.self)
        async let stats = request("stats", as: Stats.self)
        async let history = request("candles?granularity=86400", as: [[Double]].self)
        let (tick, stat, rows) = try await (ticker, stats, history)
        let formatter = ISO8601DateFormatter()
        formatter.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
        let tradeTime = formatter.date(from: tick.time) ?? ISO8601DateFormatter().date(from: tick.time)
        guard let price = Double(tick.price), price.isFinite, price > 0,
              let open = Double(stat.open), open.isFinite, open > 0,
              let tradeTime = tradeTime else { throw DataError.invalid }
        var unique: [Double: Candle] = [:]
        for row in rows where row.count >= 5 && row.allSatisfy({ $0.isFinite }) {
            guard row[1] > 0, row[2] >= row[1], row[4] > 0 else { continue }
            unique[row[0]] = Candle(date: Date(timeIntervalSince1970: row[0]), low: row[1], high: row[2], close: row[4])
        }
        let candles = unique.values.sorted { $0.date < $1.date }
        guard candles.count >= 51 else { throw DataError.invalid }
        return Snapshot(price: price, change: (price / open - 1) * 100, candles: candles, tradeTime: tradeTime)
    }
}
struct Technicals {
    let closed: [Candle]
    init(_ candles: [Candle], now: Date = Date()) {
        closed = candles.filter { $0.date.addingTimeInterval(86400) <= now }
    }
    func sma(_ days: Int) -> Double? {
        guard closed.count >= days else { return nil }
        return closed.suffix(days).map(\.close).reduce(0, +) / Double(days)
    }
    var rsi: Double? {
        let closes = closed.map(\.close)
        guard closes.count >= 15 else { return nil }
        let changes = zip(closes.dropFirst(), closes).map { $0.0 - $0.1 }
        // Wilder smoothing, seeded with the first fourteen completed sessions.
        var gain = changes.prefix(14).map { max(0, $0) }.reduce(0, +) / 14
        var loss = changes.prefix(14).map { max(0, -$0) }.reduce(0, +) / 14
        for delta in changes.dropFirst(14) {
            gain = (gain * 13 + max(delta, 0)) / 14
            loss = (loss * 13 + max(-delta, 0)) / 14
        }
        if gain == 0 && loss == 0 { return 50 }
        if loss == 0 { return 100 }
        return 100 - 100 / (1 + gain / loss)
    }
    var support: Double? { closed.suffix(20).map(\.low).min() }
    var resistance: Double? { closed.suffix(20).map(\.high).max() }
    var trend: String {
        guard let fast = sma(20), let slow = sma(50), let last = closed.last?.close else { return "بيانات غير كافية" }
        if last > fast && fast > slow { return "ميل صاعد" }
        if last < fast && fast < slow { return "ميل هابط" }
        return "اتجاه مختلط"
    }
}

@MainActor
final class MarketModel: ObservableObject {
    @Published var snapshot: Snapshot?
    @Published var error: String?
    @Published var loading = false
    @Published var fetched: Date?
    func refresh() async {
        guard !loading else { return }
        loading = true
        defer { loading = false }
        do {
            snapshot = try await MarketAPI.load()
            fetched = Date()
            error = nil
        } catch is CancellationError { }
        catch { self.error = error.localizedDescription }
    }
}

struct Dashboard: View {
    @StateObject private var model = MarketModel()
    @Environment(\.scenePhase) private var phase
    @State private var days = 30
    @AppStorage("targetUSD") private var targetUSD = ""
    private let gold = Color(red: 1, green: 0.72, blue: 0.26)
    private func money(_ value: Double) -> String {
        value.formatted(.currency(code: "USD").precision(.fractionLength(0)))
    }
    private var target: Double? {
        guard let value = Double(targetUSD), value.isFinite, value > 0 else { return nil }
        return value
    }
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 20) {
                    HStack {
                        VStack(alignment: .leading) {
                            Text("BITCOIN PULSE").font(.caption.weight(.bold)).foregroundStyle(gold)
                            Text("نبض البيتكوين").font(.largeTitle.bold())
                        }
                        Spacer()
                        Image(systemName: "bitcoinsign.circle.fill").font(.system(size: 46)).foregroundStyle(gold)
                    }
                    if let error = model.error {
                        card {
                            Text("تعذّر التحديث").font(.headline).foregroundStyle(.orange)
                            Text(error).font(.caption)
                            if model.snapshot != nil { Text("المعروض آخر بيانات ناجحة؛ قد تكون قديمة.").font(.caption) }
                            Button("إعادة المحاولة") { Task { await model.refresh() } }
                        }
                    }
                    if let data = model.snapshot {
                        quote(data)
                        chart(data)
                        analysis(data)
                        card {
                            Text("راقب سعر هدفك").font(.headline)
                            TextField("السعر بالدولار", text: $targetUSD).keyboardType(.decimalPad)
                                .textFieldStyle(.roundedBorder)
                            if let target = target {
                                Text(data.price >= target ? "السعر عند هدفك أو أعلى منه" : "المتبقي للهدف: \(money(target - data.price))")
                                    .foregroundStyle(gold)
                            } else if !targetUSD.isEmpty {
                                Text("أدخل رقماً موجباً بالأرقام الإنجليزية.").font(.caption).foregroundStyle(.orange)
                            }
                            Text("المتابعة داخل التطبيق فقط؛ لا توجد إشعارات في الخلفية.").font(.caption).foregroundStyle(.secondary)
                        }
                    } else if model.loading {
                        ProgressView("جاري تحميل بيانات السوق…").frame(maxWidth: .infinity).padding(40)
                    } else {
                        Text("اتصل بالإنترنت واضغط تحديث لعرض بيانات السوق.").foregroundStyle(.secondary)
                    }
                    Text("المصدر: Coinbase Exchange • BTC/USD\nالتحليل آلي من الأسعار التاريخية، ولا يضمن حركة مستقبلية. لا توجد أوامر شراء أو بيع، ولا توقع سنوي محسوب.")
                        .font(.footnote).foregroundStyle(.secondary)
                }.padding(20)
            }
            .background(Color(red: 0.035, green: 0.05, blue: 0.09))
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button { Task { await model.refresh() } } label: { Image(systemName: "arrow.clockwise") }
                        .disabled(model.loading)
                }
                ToolbarItemGroup(placement: .keyboard) { Spacer(); Button("تم") { hideKeyboard() } }
            }
            .refreshable { await model.refresh() }
            .task(id: phase) {
                guard phase == .active else { return }
                while !Task.isCancelled {
                    await model.refresh()
                    do { try await Task.sleep(nanoseconds: 60_000_000_000) } catch { break }
                }
            }
        }.tint(gold)
    }
    private func hideKeyboard() {
        UIApplication.shared.sendAction(#selector(UIResponder.resignFirstResponder), to: nil, from: nil, for: nil)
    }
    private func card<Content: View>(@ViewBuilder content: () -> Content) -> some View {
        VStack(alignment: .leading, spacing: 12, content: content)
            .frame(maxWidth: .infinity, alignment: .leading).padding(18)
            .background(Color.white.opacity(0.055), in: RoundedRectangle(cornerRadius: 22))
    }
    private func quote(_ data: Snapshot) -> some View {
        card {
            Text(money(data.price)).font(.system(size: 40, weight: .bold, design: .rounded)).minimumScaleFactor(0.5).lineLimit(1)
            Text(String(format: "%+.2f%% خلال 24 ساعة", data.change))
                .foregroundStyle(data.change >= 0 ? Color.green : Color.red)
            Text("وقت آخر صفقة: \(data.tradeTime.formatted(date: .abbreviated, time: .standard))").font(.caption).foregroundStyle(.secondary)
            if let fetched = model.fetched {
                Text("تم الجلب: \(fetched.formatted(date: .omitted, time: .shortened)) • تحديث كل دقيقة أثناء فتح التطبيق")
                    .font(.caption2).foregroundStyle(.secondary)
            }
        }
    }
    private func chart(_ data: Snapshot) -> some View {
        card {
            Text("حركة السعر").font(.headline)
            Picker("الفترة", selection: $days) {
                Text("أسبوع").tag(7); Text("شهر").tag(30); Text("90 يوم").tag(90)
            }.pickerStyle(.segmented)
            Chart(Array(data.candles.suffix(days))) { candle in
                LineMark(x: .value("التاريخ", candle.date), y: .value("الإغلاق", candle.close))
                    .foregroundStyle(gold)
            }
            .chartYScale(domain: .automatic(includesZero: false))
            .frame(height: 200)
            .environment(\.layoutDirection, .leftToRight)
            Text("إغلاقات يومية بتوقيت UTC؛ شمعة اليوم غير مكتملة.").font(.caption2).foregroundStyle(.secondary)
        }
    }
    private func analysis(_ data: Snapshot) -> some View {
        let tech = Technicals(data.candles)
        return card {
            Text("قراءة الاتجاه • \(tech.trend)").font(.headline)
            metric("متوسط 20 يوماً", tech.sma(20).map(money) ?? "—")
            metric("متوسط 50 يوماً", tech.sma(50).map(money) ?? "—")
            metric("RSI • 14 يوماً", tech.rsi.map { String(format: "%.1f", $0) } ?? "—")
            metric("أدنى 20 يوماً • دعم محتمل", tech.support.map(money) ?? "—")
            metric("أعلى 20 يوماً • مقاومة محتملة", tech.resistance.map(money) ?? "—")
            Divider()
            Text("سيناريوهات للمراقبة").font(.subheadline.bold())
            Text("تجاوز أعلى 20 يوماً والثبات فوقه يدعم احتمال استمرار الصعود. كسر أدنى 20 يوماً يزيد احتمال الضعف. البقاء بينهما لا يؤكد اتجاهاً.")
                .font(.subheadline).foregroundStyle(.secondary)
            Text("المؤشرات تستخدم الشموع اليومية المكتملة فقط. RSI فوق 70 أو تحت 30 يصف الزخم، ولا يضمن انعكاس السعر.")
                .font(.caption).foregroundStyle(.secondary)
        }
    }
    private func metric(_ title: String, _ value: String) -> some View {
        HStack { Text(title).foregroundStyle(.secondary); Spacer(); Text(value).monospacedDigit() }.font(.subheadline)
    }
}
