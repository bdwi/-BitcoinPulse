#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
command -v xcodebuild >/dev/null || { echo 'Requires macOS and Xcode'; exit 1; }
command -v xcodegen >/dev/null || { echo 'Install XcodeGen: brew install xcodegen'; exit 1; }
xcodegen generate
xcodebuild -project BitcoinPulse.xcodeproj -scheme BitcoinPulse -configuration Release -sdk iphoneos -destination 'generic/platform=iOS' -derivedDataPath build CODE_SIGNING_ALLOWED=NO CODE_SIGNING_REQUIRED=NO build
mkdir -p dist/Payload
rm -rf dist/Payload/BitcoinPulse.app
cp -R build/Build/Products/Release-iphoneos/BitcoinPulse.app dist/Payload/
/usr/libexec/PlistBuddy -c "Delete :UILaunchScreen" dist/Payload/BitcoinPulse.app/Info.plist || true
/usr/libexec/PlistBuddy -c "Add :UILaunchScreen dict" dist/Payload/BitcoinPulse.app/Info.plist
rm -f dist/BitcoinPulse-unsigned.ipa
(cd dist && /usr/bin/zip -qry BitcoinPulse-unsigned.ipa Payload)
echo 'Ready: dist/BitcoinPulse-unsigned.ipa — sign before installing.'
