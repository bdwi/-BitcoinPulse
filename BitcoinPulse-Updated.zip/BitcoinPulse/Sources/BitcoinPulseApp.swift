import SwiftUI
import Charts
import UserNotifications

final class NotificationDelegate: NSObject, UNUserNotificationCenterDelegate {
    static let shared = NotificationDelegate()
    func userNotificationCenter(_ center: UNUserNotificationCenter, willPresent notification: UNNotification, withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions) -> Void) {
        completionHandler([.banner, .sound, .list])
    }
}

@main
struct BitcoinPulseApp: App {
    init() { UNUserNotificationCenter.current().delegate = NotificationDelegate.shared }
    var body: some Scene {
        WindowGroup { MarketHome().preferredColorScheme(.dark).environment(\.layoutDirection, .rightToLeft) }
    }
}
struct Coin: Decodable, Identifiable {
    let id: String
    let symbol: String
    let name: String
    let image: String?
    let current_price: Double?
    let market_cap_rank: Int?
    let total_volume: Double?
    let market_cap: Double?
    let price_change_percentage_24h: Double?
    let last_updated: String?
    let sparkline_in_7d: Spark?
    struct Spark: Decodable { let price: [Double] }
    var prices: [Double] { (sparkline_in_7d?.price ?? []).filter { $0.isFinite && $0 > 0 } }
    var trend: String {
        let p = prices
        guard p.count >= 48, let last = p.last else { return "بيانات غير كافية" }
        let fast = p.suffix(12).reduce(0,+) / 12
        let slow = p.suffix(48).reduce(0,+) / 48
        if last > fast && fast > slow { return "ميل صاعد" }
        if last < fast && fast < slow { return "ميل هابط" }
        return "اتجاه مختلط"
    }
    var rsi: Double? {
        let p = prices
        guard p.count >= 15 else { return nil }
        let deltas = zip(p.suffix(15).dropFirst(), p.suffix(15)).map { $0.0 - $0.1 }
        let up = deltas.map { max(0,$0) }.reduce(0,+)
        let down = deltas.map { max(0,-$0) }.reduce(0,+)
        if up == 0 && down == 0 { return 50 }
        return down == 0 ? 100 : 100 - 100 / (1 + up / down)
    }
}
func usd(_ number: Double?) -> String {
    guard let n = number, n.isFinite else { return "—" }
    return n.formatted(.currency(code: "USD").precision(.fractionLength(n < 1 ? 6 : 2)))
}
let gold = Color(red: 1, green: 0.72, blue: 0.25)

@MainActor
final class MarketStore: ObservableObject {
    @Published var coins: [Coin] = []
    @Published var loading = false
    @Published var error: String?
    @Published var fetched: Date?
    @Published var notice = "لم يتم تفعيل الإشعارات"
    @Published var events: [String] = []
    private var previous: [String: Double] = [:]
    private var lastSent: [String: Date] = [:]
    func enableNotifications() async {
        do {
            let ok = try await UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound, .badge])
            notice = ok ? "مسموح بها • الفحص أثناء فتح التطبيق فقط" : "الإذن مرفوض • فعّله من إعدادات الآيفون"
        } catch { notice = error.localizedDescription }
    }
    func refresh() async {
        guard !loading else { return }
        loading = true
        defer { loading = false }
        do {
            let url = URL(string: "https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&order=market_cap_desc&per_page=100&page=1&sparkline=true")!
            var request = URLRequest(url: url)
            request.timeoutInterval = 30
            request.setValue("application/json", forHTTPHeaderField: "Accept")
            let (data, response) = try await URLSession.shared.data(for: request)
            guard let http = response as? HTTPURLResponse else { throw URLError(.badServerResponse) }
            guard http.statusCode == 200 else {
                error = http.statusCode == 429 ? "وصلنا لحد المصدر المجاني. انتظر قبل التحديث." : "تعذّر جلب البيانات (\(http.statusCode)). المعروض قديم إن وُجد."
                return
            }
            let decoded = try JSONDecoder().decode([Coin].self, from: data)
            guard !decoded.isEmpty else { throw URLError(.cannotParseResponse) }
            let now = Date()
            if UserDefaults.standard.bool(forKey: "priceAlerts") {
                for coin in decoded {
                    guard let price = coin.current_price, price > 0, let old = previous[coin.id], old > 0 else { continue }
                    let delta = (price / old - 1) * 100
                    guard abs(delta) >= 2, now.timeIntervalSince(lastSent[coin.id] ?? .distantPast) >= 3600 else { continue }
                    let message = "\(coin.symbol.uppercased()): \(String(format: "%+.2f%%", delta)) منذ الفحص السابق • \(usd(price))"
                    events.insert(message, at: 0)
                    let content = UNMutableNotificationContent()
                    content.title = "نبض السوق • تغير سعر"
                    content.body = message
                    content.sound = .default
                    try? await UNUserNotificationCenter.current().add(UNNotificationRequest(identifier: UUID().uuidString, content: content, trigger: nil))
                    lastSent[coin.id] = now
                }
            }
            events = Array(events.prefix(30))
            previous = Dictionary(uniqueKeysWithValues: decoded.compactMap { coin in coin.current_price.map { (coin.id, $0) } })
            coins = decoded
            fetched = now
            error = nil
        } catch is CancellationError {} catch { self.error = "تعذّر الاتصال. \(error.localizedDescription)" }
    }
}

struct MarketHome: View {
    @StateObject private var store = MarketStore()
    @Environment(\.scenePhase) private var phase
    @State private var query = ""
    @AppStorage("priceAlerts") private var alerts = false
    @AppStorage("favorites") private var favorites = "bitcoin,ethereum,solana"
    @State private var onlyFavorites = false
    var filtered: [Coin] {
        store.coins.filter { coin in
            let match = query.isEmpty || coin.name.localizedCaseInsensitiveContains(query) || coin.symbol.localizedCaseInsensitiveContains(query)
            return match && (!onlyFavorites || favorites.split(separator: ",").contains(Substring(coin.id)))
        }
    }
    var body: some View {
        TabView {
            NavigationStack {
                List {
                    Section {
                        Label("نبض السوق • أكبر 100 عملة", systemImage: "bitcoinsign.circle.fill").foregroundStyle(gold).font(.headline)
                        Text("مرتبة حسب القيمة السوقية • تشمل العملات المستقرة").font(.caption).foregroundStyle(.secondary)
                        if let date = store.fetched { Text("آخر جلب: \(date.formatted(date: .omitted, time: .shortened)) • المصدر: CoinGecko").font(.caption) }
                        if let error = store.error { Text(error).foregroundStyle(.orange).font(.caption) }
                        if store.loading { ProgressView("جاري التحديث…") }
                        Toggle("المفضلة فقط", isOn: $onlyFavorites)
                    }
                    Section("\(filtered.count) عملة • الأسعار بالدولار") {
                        ForEach(filtered) { coin in
                            NavigationLink { CoinScreen(coin: coin, favorites: $favorites) } label: {
                                HStack(spacing: 10) {
                                    AsyncImage(url: URL(string: coin.image ?? "")) { image in image.resizable().scaledToFit() } placeholder: { Image(systemName: "circle.hexagongrid.fill").foregroundStyle(gold) }.frame(width: 32, height: 32)
                                    VStack(alignment: .leading) {
                                        Text(coin.symbol.uppercased()).font(.headline)
                                        Text("#\(coin.market_cap_rank ?? 0) \(coin.name)").font(.caption).foregroundStyle(.secondary)
                                    }
                                    Spacer()
                                    VStack(alignment: .trailing) {
                                        Text(usd(coin.current_price)).font(.subheadline).monospacedDigit()
                                        Text(coin.price_change_percentage_24h.map { String(format: "%+.2f%%", $0) } ?? "—")
                                            .foregroundStyle((coin.price_change_percentage_24h ?? 0) >= 0 ? Color.green : Color.red).font(.caption)
                                    }
                                }
                            }
                        }
                    }
                    Section { Text("البيانات من CoinGecko • التحليل وصفي واحتمالي، وليس توصية تداول أو ضماناً للربح.").font(.caption).foregroundStyle(.secondary) }
                }
                .searchable(text: $query, prompt: "ابحث باسم العملة أو رمزها")
                .navigationTitle("نبض العملات")
                .toolbar { Button { Task { await store.refresh() } } label: { Image(systemName: "arrow.clockwise") }.disabled(store.loading) }
                .refreshable { await store.refresh() }
            }.tabItem { Label("السوق", systemImage: "chart.line.uptrend.xyaxis") }
            NavigationStack {
                Form {
                    Section("تنبيهات السعر") {
                        Toggle("تنبيه تغير 2% بين فحصين", isOn: $alerts)
                        Button("السماح بإشعارات الآيفون") { Task { await store.enableNotifications() } }
                        Text(store.notice).font(.caption)
                        Text("يفحص كل 5 دقائق أثناء فتح التطبيق، ويمنع تكرار تنبيه العملة خلال ساعة. أول جلب يحدد نقطة المقارنة. عند إغلاق التطبيق تتوقف المراقبة؛ خدمة الخلفية لم تُربط بعد.").font(.caption).foregroundStyle(.secondary)
                    }
                    Section("آخر الإشارات • هذه الجلسة") {
                        if store.events.isEmpty { Text("لا توجد إشارات مسجلة بعد").foregroundStyle(.secondary) }
                        ForEach(Array(store.events.enumerated()), id: \.offset) { item in Text(item.element).font(.subheadline) }
                    }
                    Section("السيولة والمحافظ") {
                        Label("غير متصلة", systemImage: "link.badge.plus").foregroundStyle(.orange)
                        Text("لا تتوفر بعد خدمة مراقبة المحافظ والتحويلات أو عمق دفتر الأوامر. حجم التداول ليس صافي دخول أو خروج السيولة. لن يرسل التطبيق تنبيهات محافظ أو حيتان قبل ربط مصدر فعلي.").font(.subheadline)
                    }
                }.navigationTitle("التنبيهات")
            }.tabItem { Label("التنبيهات", systemImage: "bell") }
        }.tint(gold)
        .task(id: phase) {
            guard phase == .active else { return }
            while !Task.isCancelled {
                await store.refresh()
                do { try await Task.sleep(nanoseconds: 300_000_000_000) } catch { break }
            }
        }
    }
}

struct CoinScreen: View {
    let coin: Coin
    @Binding var favorites: String
    var body: some View {
        List {
            Section {
                Text(usd(coin.current_price)).font(.largeTitle.bold()).minimumScaleFactor(0.5).lineLimit(1)
                Text("تغير 24 ساعة: " + (coin.price_change_percentage_24h.map { String(format: "%+.2f%%", $0) } ?? "—"))
                Text("وقت بيانات المصدر: \(coin.last_updated ?? "غير متاح")").font(.caption).foregroundStyle(.secondary)
                Button(favorites.split(separator: ",").contains(Substring(coin.id)) ? "إزالة من المفضلة" : "إضافة للمفضلة") {
                    var ids = Set(favorites.split(separator: ",").map(String.init))
                    if ids.contains(coin.id) { ids.remove(coin.id) } else { ids.insert(coin.id) }
                    favorites = ids.sorted().joined(separator: ",")
                }
            }
            Section("حركة آخر 7 أيام") {
                if coin.prices.count >= 2 {
                    Chart(Array(coin.prices.enumerated()), id: \.offset) { point in
                        LineMark(x: .value("العينة", point.offset), y: .value("السعر", point.element)).foregroundStyle(gold)
                    }.chartYScale(domain: .automatic(includesZero: false)).frame(height: 190).environment(\.layoutDirection, .leftToRight)
                    Text("عينات المصدر؛ قد تتضمن الفترة الحالية غير المكتملة.").font(.caption)
                } else { Text("الرسم غير متاح من المصدر") }
            }
            Section("التحليل والسيناريوهات") {
                Text(coin.trend).font(.headline).foregroundStyle(gold)
                Text("الميل يقارن متوسط آخر 12 و48 عينة بالسعر الأخير؛ ليس توقعاً مؤكداً.").font(.caption)
                LabeledContent("RSI مبسط • 14 تغيراً", value: coin.rsi.map { String(format: "%.1f", $0) } ?? "—")
                if coin.prices.count >= 48 {
                    let reference = Array(coin.prices.dropLast().suffix(48))
                    let low = reference.min()
                    let high = reference.max()
                    LabeledContent("أدنى النطاق السابق", value: usd(low))
                    LabeledContent("أعلى النطاق السابق", value: usd(high))
                    Text("سيناريو صعود: تجاوز \(usd(high)) والثبات فوقه قد يدعم الزخم. سيناريو هبوط: كسر \(usd(low)) قد يزيد الضعف. داخل النطاق تبقى الحركة غير محسومة.")
                }
                Text("لا تتوفر نسبة ثقة مُعايرة أو نموذج توقع مختبر؛ لا نعرض أرقام احتمالات مصطنعة.").font(.caption).foregroundStyle(.secondary)
            }
            Section("حجم التداول • ليس صافي السيولة") {
                LabeledContent("تداول 24 ساعة", value: usd(coin.total_volume))
                LabeledContent("القيمة السوقية", value: usd(coin.market_cap))
                Text("هذه أرقام مجمعة من المصدر، ولا تحدد مشترياً أو بائعاً أو حركة محافظ المنصات.").font(.caption)
            }
            Link("بيانات CoinGecko", destination: URL(string: "https://www.coingecko.com/en/coins/\(coin.id)")!)
        }.navigationTitle(coin.name).navigationBarTitleDisplayMode(.inline)
    }
}
